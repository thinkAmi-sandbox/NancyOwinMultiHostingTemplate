using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class RazorConfig : Nancy.ViewEngines.Razor.IRazorConfiguration
    {
        public IEnumerable<string> GetAssemblyNames()
        {
            yield return "$safeprojectname$";
        }

        public IEnumerable<string> GetDefaultNamespaces()
        {
            yield return "$safeprojectname$";
        }

        public bool AutoIncludeModelNamespace
        {
            get { return true; }
        }
    }
}
